public abstract class Room
 {
    protected String roomNumber;
    protected boolean isAvailable;

    public Room(String roomNumber) 
    {
        this.roomNumber = roomNumber;
        this.isAvailable = true;
    }

    public String getRoomNumber()
     {
        return roomNumber;
    }

    public boolean isAvailable()
     {
        return isAvailable;
    }

    public void book() 
    {
        isAvailable = false;
    }

    public void cancel()
     {
        isAvailable = true;
    }

    public abstract double getPrice();

    @Override
    public String toString()
     {
        return roomNumber + "," + (isAvailable ? "Available" : "Booked") + "," + getPrice();
    }
}
