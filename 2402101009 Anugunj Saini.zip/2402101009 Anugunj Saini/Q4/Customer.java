public class Customer 
{
    private String id;
    private String name;
    private String contactNumber;

    public Customer(String id, String name, String contactNumber)
     {
        this.id = id;
        this.name = name;
        this.contactNumber = contactNumber;
    }

    public String getId() 
    {
        return id;
    }

    public String getName() 
    {
        return name;
    }

    public String getContactNumber()
     {
        return contactNumber;
    }

    @Override
    public String toString()
     {
        return id + "," + name + "," + contactNumber;
    }
}
