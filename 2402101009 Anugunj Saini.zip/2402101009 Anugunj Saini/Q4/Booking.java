public class Booking 
{
    private String bookingId;
    private Customer customer;
    private Room room;

    public Booking(String bookingId, Customer customer, Room room) {
        this.bookingId = bookingId;
        this.customer = customer;
        this.room = room;
    }

    public String getBookingId() 
    {
        return bookingId;
    }

    public Customer getCustomer() 
    {
        return customer;
    }

    public Room getRoom()
     {
        return room;
    }

    @Override
    public String toString()
     {
        return bookingId + "," + customer.getId() + "," + room.getRoomNumber();
    }
}
