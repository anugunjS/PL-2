public class SuiteRoom extends Room 
{
    private static final double PRICE = 500.0; 
    public SuiteRoom(String roomNumber)
     {
        super(roomNumber);
    }

    @Override
    public double getPrice()
     {
        return PRICE;
    }
}
