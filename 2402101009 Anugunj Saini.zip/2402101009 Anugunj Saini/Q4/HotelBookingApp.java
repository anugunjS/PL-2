import java.util.Scanner;

public class HotelBookingApp 
{
    private static final Hotel hotel = new Hotel();
    private static final Scanner scanner = new Scanner(System.in);

    public static void main(String[] args)
     {
        initializeHotel();

        while (true)
         {
            System.out.println("\nHotel Booking System Menu:");
            System.out.println("1. List Rooms");
            System.out.println("2. List Bookings");
            System.out.println("3. Book Room");
            System.out.println("4. Cancel Booking");
            System.out.println("5. Exit");
            System.out.print("Choose an option: ");

            int option = Integer.parseInt(scanner.nextLine());

            switch (option) 
            {
                case 1 -> hotel.listRooms();
                case 2 -> hotel.listBookings();
                case 3 -> bookRoom();
                case 4 -> cancelBooking();
                case 5 -> {
                    System.out.println("Exiting...");
                    return;
                }
                default -> System.out.println("Invalid option. Try again.");
            }
        }
    }

    private static void initializeHotel()
     {
        hotel.addRoom(new SingleRoom("211"));
        hotel.addRoom(new DoubleRoom("212"));
        hotel.addRoom(new SuiteRoom("213"));
    }

    private static void bookRoom() 
    {
        System.out.print("Enter room number to book: ");
        String roomNumber = scanner.nextLine();
        System.out.print("Enter customer ID: ");
        String customerId = scanner.nextLine();
        System.out.print("Enter customer name: ");
        String customerName = scanner.nextLine();
        System.out.print("Enter customer contact number: ");
        String contactNumber = scanner.nextLine();

        Customer customer = new Customer(customerId, customerName, contactNumber);

        try {
            hotel.bookRoom(roomNumber, customer);
            System.out.println("Room booked successfully.");
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    private static void cancelBooking() 
    {
        System.out.print("Enter booking ID to cancel: ");
        String bookingId = scanner.nextLine();

        try
         {

            hotel.cancelBooking(bookingId);
            System.out.println("Booking canceled successfully.");
        } catch (Exception e) 
        {
            System.out.println(e.getMessage());
        }
    }
}
