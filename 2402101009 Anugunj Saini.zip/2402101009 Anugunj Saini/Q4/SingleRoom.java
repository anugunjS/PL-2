public class SingleRoom extends Room 
{
    private static final double PRICE = 300.0;

    public SingleRoom(String roomNumber)
     {
        super(roomNumber);
    }

    @Override
    public double getPrice()
     {
        return PRICE;
    }
}

