public class DoubleRoom extends Room
 {
    private static final double PRICE = 450.0; 

    public DoubleRoom(String roomNumber) 
    {
        super(roomNumber);
    }

    @Override
    public double getPrice() 
    {
        return PRICE;
    }
}
