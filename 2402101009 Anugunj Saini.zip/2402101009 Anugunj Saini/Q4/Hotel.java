import java.util.HashMap;
import java.util.Map;

public class Hotel
 {
    private Map<String, Room> rooms = new HashMap<>();
    private Map<String, Booking> bookings = new HashMap<>();

    public void addRoom(Room room) {
        rooms.put(room.getRoomNumber(), room);
    }

    public boolean checkRoomAvailability(String roomNumber)
     {
        Room room = rooms.get(roomNumber);
        return room != null && room.isAvailable();
    }

    public void bookRoom(String roomNumber, Customer customer) throws Exception
     {
        Room room = rooms.get(roomNumber);
        if (room == null) throw new Exception("Room not found.");
        if (!room.isAvailable()) throw new Exception("Room is already booked.");

        room.book();
        String bookingId = "BOOK" + System.currentTimeMillis();
        Booking booking = new Booking(bookingId, customer, room);
        bookings.put(bookingId, booking);
    }

    public void cancelBooking(String bookingId) throws Exception
     {
        Booking booking = bookings.get(bookingId);
        if (booking == null) throw new Exception("Booking not found.");

        Room room = booking.getRoom();
        room.cancel();
        bookings.remove(bookingId);
    }

    public void listRooms()
     {
        for (Room room : rooms.values()) 
        {
            System.out.println(room);
        }
    }

    public void listBookings() {
        for (Booking booking : bookings.values()) 
        {
            System.out.println(booking);
        }
    }
}
