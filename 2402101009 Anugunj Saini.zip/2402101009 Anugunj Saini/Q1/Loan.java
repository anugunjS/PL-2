import java.io.Serializable;
import java.time.LocalDate;

public class Loan implements Serializable
{
    private Book book;
    private Member member;
    private LocalDate loanDate;

    public Loan(Book book, Member member, LocalDate loanDate) {
        this.book = book;
        this.member = member;
        this.loanDate = loanDate;
    }

    public Book getBook()
     {
        return book;
    }

    public void setBook(Book book)
     {
        this.book = book;
    }

    public Member getMember() 
    {
        return member;
    }

    public void setMember(Member member)
     {
        this.member = member;
    }

    public LocalDate getLoanDate() 
    {
        return loanDate;
    }

    public void setLoanDate(LocalDate loanDate)
     {
        this.loanDate = loanDate;
    }

    @Override
    public String toString() 
    {

        return "Book: " + book + ", Member: " + member + ", Loan Date: " + loanDate;
    }
}
