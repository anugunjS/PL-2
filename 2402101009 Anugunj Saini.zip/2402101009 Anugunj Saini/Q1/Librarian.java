import java.io.Serializable;

public class Librarian implements Serializable 
{
    private String librarianId;
    private String name;

    public Librarian(String librarianId, String name)
     {
        this.librarianId = librarianId;
        this.name = name;
    }

    // Getters and setters
    public String getLibrarianId()
     {
        return librarianId;
    }

    public void setLibrarianId(String librarianId) 
    {
        this.librarianId = librarianId;
    }

    public String getName()
     {
        return name;
    }

    public void setName(String name)
     {
        this.name = name;
    }

    @Override
    public String toString()
     {
        return "ID: " + librarianId + ", Name: " + name;
    }
}
