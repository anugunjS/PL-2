import java.util.Scanner;

public class LibraryMS
 {
    private static Library library = Library.loadData();
    public static void main(String[] args)
     {
        boolean check = true;
        while (check)
         {
            System.out.println("\nLibrary Management System\n\n");
            System.out.println("1.ADMIN");
            System.out.println("2.STUDENT");
            System.out.println("3.EXIT");
            int log =getIn();
            switch(log)
            {
                case 1:
                System.out.println("1. Add Book");
                System.out.println("2. Remove Book");
                System.out.println("3. Update Book");
                System.out.println("4. Add Member");
                System.out.println("5. Remove Member");
                System.out.println("6. Print Book Records");
                System.out.println("7. Print Loaned Books Details");
                System.out.println("8. Save and Exit");
                System.out.print("Enter your choice: ");
                int ad = getIn();
                switch (ad)
                 {
                    case 1:
                        addBook();
                        break;
                    case 2:
                        removeBook();
                        break;
                    case 3:
                        updateBook();
                        break;
                    case 4:
                        addMember();
                        break;
                    case 5:
                        removeMember();
                        break;
                    case 6:
                        library.printBookRecords();
                        break;
                    case 7:
                        library.printLoanedBooksDetails();
                        break;
                    case 8:
                        library.saveData();
                        check = false;
                        System.out.println("Data saved. Exiting...");
                        break;
                    default:
                        System.out.println("Invalid choice. Please try again.");
                }
                break;
                case 2:
                System.out.println("1. Issue Book");
                System.out.println("2. Return Book");
                System.out.println("3. Print Book Records");
                System.out.println("4. Print Loaned Books Details");
                System.out.println("5. Save and Exit");
                System.out.print("Enter your choice: ");
                int st = getIn();
                switch (st) 
                {
                    case 1:
                        issueBook();
                        break;
                    case 2:
                        returnBook();
                        break;
                    case 3:
                        library.printBookRecords();
                        break;
                    case 4:
                        library.printLoanedBooksDetails();
                        break;
                    case 5:
                        library.saveData();
                        check = false;
                        System.out.println("Data saved. Exiting...");
                        break;
                    default:
                        System.out.println("Invalid choice. Please try again.");
                }
                default:
                    return;

            }
             }
        
    }

    private static String getS()
    {
        Scanner ins= new Scanner(System.in);
        return (ins.nextLine());
    }
    private static int getIn()
    {
        Scanner in= new Scanner(System.in);
        return (in.nextInt());
    }


    private static void addBook() 
    {
        System.out.print("Enter Book ID: ");
        String bookId = getS();
        
        System.out.print("Enter Author: ");
        String author = getS();

        System.out.print("Enter Title: ");
        String title = getS();
        System.out.print("Enter Year: ");
        int year = getIn();
        library.addBook(new Book(bookId, title, author, year, true));
        System.out.println("Book added successfully.");
    }

    private static void removeBook()
     {
        System.out.print("Enter Book ID to remove: ");
        String bookId =getS();
        library.removeBook(bookId);
        System.out.println("Book removed successfully.");
        
    }

    private static void updateBook() 
    {
        System.out.print("Enter Book ID to update: ");
        String bookId = getS();
        System.out.print("Enter new Title (or press Enter to skip): ");
        String title =getS();
        System.out.print("Enter new Author (or press Enter to skip): ");
        String author = getS();
        System.out.print("Enter new Year (or enter 0 to skip): ");
        int year = getIn();
        System.out.print("Enter Availability (true/false or press Enter to skip): ");
        String availabilityInput = getS();
        Boolean available = availabilityInput.isEmpty() ? null : Boolean.parseBoolean(availabilityInput);
        library.updateBook(bookId, title.isEmpty() ? null : title, author.isEmpty() ? null : author, year, available);
        System.out.println("Book updated successfully.");
    }

    private static void addMember()
     {
        System.out.print("Enter Member ID: ");
        String memberId =getS();
        System.out.print("Enter Name: ");
        String name = getS();
        library.addMember(new Member(memberId, name));
        System.out.println("Member added successfully.");
    }

    private static void removeMember()
     {
        System.out.print("Enter Member ID to remove: ");
        String memberId =getS();
        library.removeMember(memberId);
        System.out.println("Member removed successfully.");
        
    }

    private static void issueBook()
     {
        System.out.print("Enter Book ID to issue: ");
        String bookId = getS();
        System.out.print("Enter Member ID: ");
        String memberId = getS();
        library.issueBook(bookId, memberId);
        System.out.println("Book issued successfully.");
        
    }

    private static void returnBook()
     {
        System.out.print("Enter Book ID to return: ");
        String bookId = getS();
        System.out.print("Enter Member ID: ");
        String memberId = getS();
        library.returnBook(bookId, memberId);
        System.out.println("Book returned successfully.");
     }
        
   
}
