import java.io.*;
import java.time.LocalDate;
import java.util.*;

public class Library implements Serializable
 {
    private Map<String, Book> books = new HashMap<>();
    private Map<String, Member> members = new HashMap<>();
    private List<Loan> loans = new ArrayList<>();
    private static final String FILE_PATH = "library_data.ser";

    // Add a new book
    public void addBook(Book book) 
    {
        books.put(book.getBookId(), book);
    }

    // Remove a book
    public void removeBook(String bookId) throws NoSuchElementException
     {
        if (!books.containsKey(bookId)) 
        {
            throw new NoSuchElementException("Book not found.");
        }
        books.remove(bookId);
    }

    // Update a book
    public void updateBook(String bookId, String title, String author, int year, Boolean available) throws NoSuchElementException {
        Book book = books.get(bookId);
        if (book == null)
         {
            throw new NoSuchElementException("Book not found.");
        }
        if (title != null) book.setTitle(title);
        if (author != null) book.setAuthor(author);
        if (year > 0) book.setYear(year);
        if (available != null) book.setAvailable(available);
    }

    // Add a new member
    public void addMember(Member member) 
    {
        members.put(member.getMemberId(), member);
    }

    // Remove a member
    public void removeMember(String memberId) throws NoSuchElementException 
    {
        if (!members.containsKey(memberId)) 
        {
            throw new NoSuchElementException("Member not found.");
        }
        members.remove(memberId);
    }

    // Issue a book
    public void issueBook(String bookId, String memberId) throws NoSuchElementException, IllegalStateException {
        Book book = books.get(bookId);
        Member member = members.get(memberId);
        if (book == null) {
            throw new NoSuchElementException("Book not found.");
        }
        if (member == null) {
            throw new NoSuchElementException("Member not found.");
        }
        if (!book.isAvailable()) {
            throw new IllegalStateException("Book is not available.");
        }
        loans.add(new Loan(book, member, LocalDate.now()));
        book.setAvailable(false);
    }

    // Return a book
    public void returnBook(String bookId, String memberId) throws NoSuchElementException, IllegalStateException {
        Book book = books.get(bookId);
        Member member = members.get(memberId);
        if (book == null) {
            throw new NoSuchElementException("Book not found.");
        }
        if (member == null) {
            throw new NoSuchElementException("Member not found.");
        }
        Loan loanToRemove = null;
        for (Loan loan : loans) {
            if (loan.getBook().getBookId().equals(bookId) && loan.getMember().getMemberId().equals(memberId)) {
                loanToRemove = loan;
                break;
            }
        }
        if (loanToRemove == null) {
            throw new IllegalStateException("Loan record not found.");
        }
        loans.remove(loanToRemove);
        book.setAvailable(true);
    }

    // Save library data to a file
    public void saveData()
     {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(FILE_PATH))) {
            oos.writeObject(this);
        } catch (IOException e)
         {
            System.err.println("Error saving data: " + e.getMessage());
        }
    }

    // Load library data from a file
    public static Library loadData() {
        File file = new File(FILE_PATH);
        if (!file.exists()) 
        {
            return new Library(); // Return a new Library instance if no data file exists
        }
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(FILE_PATH))) 
        {
            return (Library) ois.readObject();
        } catch (IOException | ClassNotFoundException e)
         {
            System.err.println("Error loading data: " + e.getMessage());
            return new Library(); // Return a new Library instance if there is an error
        }
    }

    // Print book records
    public void printBookRecords()
     {
        if (books.isEmpty()) {
            System.out.println("No books available in the library.");
        } else {
            for (Book book : books.values()) {
                System.out.println(book);
            }
        }
    }

    // Print loaned books details
    public void printLoanedBooksDetails()
     {
        if (loans.isEmpty()) {
            System.out.println("No books are currently loaned out.");
        } else {
            for (Loan loan : loans) {
                System.out.println("Loan Record: " + loan);
            }
        }
    }
}
