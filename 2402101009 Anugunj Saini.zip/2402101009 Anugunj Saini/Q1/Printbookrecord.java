public void printLoanedBooksDetails()
 {
    if (loans.isEmpty()) 
    {
        System.out.println("No books are currently loaned out.");
    } 
    else
     {
        for (Loan loan : loans)
         {
            System.out.println("Loan Record: " + loan);
        }
    }
}
