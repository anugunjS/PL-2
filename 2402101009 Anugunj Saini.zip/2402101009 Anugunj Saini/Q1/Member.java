import java.io.Serializable;

public class Member implements Serializable
 {
    private String memberId;
    private String name;

    public Member(String memberId, String name)
     {
        this.memberId = memberId;
        this.name = name;
    }

    // Getters and setters
    public String getMemberId() 
    {
        return memberId;
    }

    public void setMemberId(String memberId) 
    {
        this.memberId = memberId;
    }

    public String getName()
     {
        return name;
    }

    public void setName(String name) 
    {
        this.name = name;
    }

    @Override
    public String toString()
     {
        return "ID: " + memberId + ", Name: " + name;
    }
}
