import java.io.IOException;
import java.util.Scanner;

public class BankingApp {

    private static final Bank bank = new Bank();
    private static final Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        try {
            bank.loadData();
        } catch (IOException e) {
            System.out.println("No existing data found, starting fresh.");
        }

        while (true) 
        {
            System.out.println("\nBanking System Menu:");
            System.out.println("1. Create Account");
            System.out.println("2. Deposit");
            System.out.println("3. Withdraw");
            System.out.println("4. Transfer");
            System.out.println("5. Exit");
            System.out.print("Choose an option: ");

            int option = Integer.parseInt(scanner.nextLine());

            switch (option)
             {
                case 1:
                    createAccount();
                    break;
                case 2:
                    deposit();
                    break;
                case 3:
                    withdraw();
                    break;
                case 4:
                    transfer();
                    break;
                case 5:
                    try {
                        bank.saveData();
                    } catch (IOException e) {
                        System.out.println("Error saving data.");
                    }
                    System.out.println("Exiting...");
                    return;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }

    private static void createAccount() {
        System.out.print("Enter account number: ");
        String accountNumber = scanner.nextLine();
        System.out.print("Enter customer ID: ");
        String customerId = scanner.nextLine();
        System.out.print("Enter customer name: ");
        String customerName = scanner.nextLine();
        System.out.print("Enter initial balance: ");
        double initialBalance = Double.parseDouble(scanner.nextLine());

        Customer customer = new Customer(customerId, customerName);
        System.out.print("Enter account type (S for Savings or C for Current): ");
        String accountType = scanner.nextLine();

        Account account;
        if (accountType.equalsIgnoreCase("S")) {
            account = new SavingsAccount(accountNumber, customer, initialBalance);
        } else if (accountType.equalsIgnoreCase("C")) {
            System.out.print("Enter overdraft limit: ");
            double overdraftLimit = Double.parseDouble(scanner.nextLine());
            account = new CurrentAccount(accountNumber, customer, initialBalance, overdraftLimit);
        } else {
            System.out.println("Invalid account type.");
            return;
        }

        bank.createAccount(account);
        System.out.println("Account created successfully.");
    }

    private static void deposit() {
        System.out.print("Enter account number: ");
        String accountNumber = scanner.nextLine();
        System.out.print("Enter amount to deposit: ");
        double amount = Double.parseDouble(scanner.nextLine());

        try {
            bank.deposit(accountNumber, amount);
            System.out.println("Deposit successful.");
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    private static void withdraw() {
        System.out.print("Enter account number: ");
        String accountNumber = scanner.nextLine();
        System.out.print("Enter amount to withdraw: ");
        double amount = Double.parseDouble(scanner.nextLine());

        try {
            bank.withdraw(accountNumber, amount);
            System.out.println("Withdrawal successful.");
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    private static void transfer() {
        System.out.print("Enter source account number: ");
        String fromAccountNumber = scanner.nextLine();
        System.out.print("Enter target account number: ");
        String toAccountNumber = scanner.nextLine();
        System.out.print("Enter amount to transfer: ");
        double amount = Double.parseDouble(scanner.nextLine());

        try {
            bank.transfer(fromAccountNumber, toAccountNumber, amount);
            System.out.println("Transfer successful.");
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
}
