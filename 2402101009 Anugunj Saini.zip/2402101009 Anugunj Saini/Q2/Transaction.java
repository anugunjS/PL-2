public class Transaction
 {
    private String transactionId;
    private Account sourceAccount;
    private Account targetAccount;
    private double amount;
    private String type;

    public Transaction(String transactionId, Account sourceAccount, Account targetAccount, double amount, String type) {
        this.transactionId = transactionId;
        this.sourceAccount = sourceAccount;
        this.targetAccount = targetAccount;
        this.amount = amount;
        this.type = type;
    }

    @Override
    public String toString() {
        return transactionId + "," + (sourceAccount != null ? sourceAccount.getAccountNumber() : "N/A") +
                "," + (targetAccount != null ? targetAccount.getAccountNumber() : "N/A") + "," +
                amount + "," + type;
    }
}
