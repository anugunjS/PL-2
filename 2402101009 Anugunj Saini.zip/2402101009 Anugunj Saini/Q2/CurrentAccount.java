public class CurrentAccount extends Account 
{
    private double overdraftLimit;

    public CurrentAccount(String accountNumber, Customer customer, double initialBalance, double overdraftLimit) {
        super(accountNumber, customer, initialBalance);
        this.overdraftLimit = overdraftLimit;
    }

    @Override
    public void deposit(double amount)
     {
        balance += amount;
    }

    @Override
    public void withdraw(double amount) throws Exception
     {
        if (amount > balance + overdraftLimit) {
            throw new Exception("Insufficient funds, overdraft limit exceeded.");
        }
        balance -= amount;
    }
}
