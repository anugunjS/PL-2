public class SavingsAccount extends Account
 {

    public SavingsAccount(String accountNumber, Customer customer, double initialBalance) 
    {
        super(accountNumber, customer, initialBalance);
    }

    @Override
    public void deposit(double amount)
     {
        balance += amount;
    }

    @Override
    public void withdraw(double amount) throws Exception {
        if (amount > balance) {
            throw new Exception("Insufficient funds.");
        }
        balance -= amount;
    }
}
