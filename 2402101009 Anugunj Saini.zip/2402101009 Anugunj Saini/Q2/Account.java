public abstract class Account
 {
    protected String accountNumber;
    protected Customer customer;
    protected double balance;

    public Account(String accountNumber, Customer customer, double initialBalance)
     {
        this.accountNumber = accountNumber;
        this.customer = customer;
        this.balance = initialBalance;
    }

    public String getAccountNumber() 
    {
        return accountNumber;
    }

    public Customer getCustomer()
     {
        return customer;
    }

    public double getBalance()
     {
        return balance;
    }

    public abstract void deposit(double amount);

    public abstract void withdraw(double amount) throws Exception;

    public void transfer(double amount, Account targetAccount) throws Exception 
    {
        withdraw(amount);
        targetAccount.deposit(amount);
    }

    @Override
    public String toString() {
        return accountNumber + "," + customer.getId() + "," + customer.getName() + "," + balance;
    }
}
