import java.io.*;
import java.util.HashMap;
import java.util.Map;

public class Bank 
{
    private Map<String, Account> accounts = new HashMap<>();
    private Map<String, Transaction> transactions = new HashMap<>();
    private static final String ACCOUNT_FILE = "accounts.txt";
    private static final String TRANSACTION_FILE = "transactions.txt";

    public void createAccount(Account account) 
    {
        accounts.put(account.getAccountNumber(), account);
    }

    public Account getAccount(String accountNumber)
     {
        return accounts.get(accountNumber);
    }

    public void deposit(String accountNumber, double amount) throws Exception
     {
        Account account = getAccount(accountNumber);
        if (account == null) {
            throw new Exception("Account not found.");
        }
        account.deposit(amount);
        recordTransaction(new Transaction(generateTransactionId(), null, account, amount, "Deposit"));
    }

    public void withdraw(String accountNumber, double amount) throws Exception 
    {
        Account account = getAccount(accountNumber);
        if (account == null) {
            throw new Exception("Account not found.");
        }
        account.withdraw(amount);
        recordTransaction(new Transaction(generateTransactionId(), account, null, amount, "Withdrawal"));
    }

    public void transfer(String fromAccountNumber, String toAccountNumber, double amount) throws Exception 
    {
        Account fromAccount = getAccount(fromAccountNumber);
        Account toAccount = getAccount(toAccountNumber);
        if (fromAccount == null || toAccount == null) {
            throw new Exception("One or both accounts not found.");
        }
        fromAccount.transfer(amount, toAccount);
        recordTransaction(new Transaction(generateTransactionId(), fromAccount, toAccount, amount, "Transfer"));
    }

    private void recordTransaction(Transaction transaction)
     {
        transactions.put(transaction.toString(), transaction);
    }

    private String generateTransactionId()
     {
        return "TXN" + System.currentTimeMillis();
    }

    public void saveData() throws IOException 
    {
        try (BufferedWriter accountWriter = new BufferedWriter(new FileWriter(ACCOUNT_FILE));
             BufferedWriter transactionWriter = new BufferedWriter(new FileWriter(TRANSACTION_FILE))) {

            for (Account account : accounts.values())
             {
                accountWriter.write(account.toString());
                accountWriter.newLine();
            }

            for (Transaction transaction : transactions.values())
             {
                transactionWriter.write(transaction.toString());
                transactionWriter.newLine();
            }
        }
    }

    public void loadData() throws IOException 
    {
        accounts.clear();
        transactions.clear();

        try (BufferedReader accountReader = new BufferedReader(new FileReader(ACCOUNT_FILE));
             BufferedReader transactionReader = new BufferedReader(new FileReader(TRANSACTION_FILE))) {

            String line;
            while ((line = accountReader.readLine()) != null)
             {
                String[] parts = line.split(",");
                Customer customer = new Customer(parts[1], parts[2]);
                Account account = parts[0].startsWith("S")
                        ? new SavingsAccount(parts[0], customer, Double.parseDouble(parts[3]))
                        : new CurrentAccount(parts[0], customer, Double.parseDouble(parts[3]), 0); // Default overdraft limit
                accounts.put(account.getAccountNumber(), account);
            }

            while ((line = transactionReader.readLine()) != null) 
            {
                String[] parts = line.split(",");
                Account sourceAccount = getAccount(parts[1]);
                Account targetAccount = getAccount(parts[2]);
                double amount = Double.parseDouble(parts[3]);
                String type = parts[4];
                Transaction transaction = new Transaction(parts[0], sourceAccount, targetAccount, amount, type);
                transactions.put(transaction.toString(), transaction);
            }
        }
    }
}
